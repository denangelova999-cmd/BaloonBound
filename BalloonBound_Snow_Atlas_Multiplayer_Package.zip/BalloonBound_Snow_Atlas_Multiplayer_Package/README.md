BalloonBound — Atlas & Multiplayer Snow/Grain UI Update

Files:
- index.html: updated game
- netlify.toml: Netlify publish configuration

Visual update:
- Added a subtle drifting snowflake and paper-grain overlay to the Skybound Atlas, multiplayer lobby, and multiplayer match screen.
- Added fine paper grain to Atlas and multiplayer panels to match the main-menu texture.
- Kept the overlay pointer-transparent and disabled its animation when reduced motion is preferred.
- No Christmas event content or gameplay logic was added or changed.

Deploy:
Upload the contents of this folder to Netlify, replacing the previous index.html.

Multiplayer note:
This is a visual front-end update. Online multiplayer still requires a deployed WebSocket server and a configured BB_MULTIPLAYER_CONFIG.url.
